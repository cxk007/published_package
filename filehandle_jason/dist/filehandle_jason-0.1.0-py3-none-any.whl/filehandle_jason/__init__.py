name = "filehandle_jason"
__all__ = ['filehandle']

from filehandle_jason.filehandle import file_encode, file_merge, file_split, file_dedup
